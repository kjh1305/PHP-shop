<?
	include "common.php";

	$no=$_REQUEST[no];
	

	$query="delete from sj where no8=$no";
	$result=mysqli_query($db,$query);
	if(!$result) exit("����:$query");

	echo("<script>location.href='sj_list.php'</script>");
	?>