<?
	$admin_id = "admin";
	$admin_pw = "1234";
	
	$page_line=5;
	$page_block=5;

	$db=mysqli_connect("localhost","shop8","1234","shop8");
	if (!$db) exit("DB연결에러");

	
?>