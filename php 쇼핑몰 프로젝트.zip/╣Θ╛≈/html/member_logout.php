<?
	setcookie("cookie_no","");
	setcookie("cookie_name","");
	setcookie("cookie_uid","");
	echo("<script>location.href='main.php'</script>");
?>